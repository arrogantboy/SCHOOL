package mx.uaemex.gui;

import java.awt.FlowLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import mx.uaemex.threads.Alarma_Thread;
import mx.uaemex.threads.Reloj_Thread;

public class Reloj_GUI extends JFrame {

    public Reloj_GUI() {
        setSize(520, 400);
        setTitle("Reloj internacional");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        //******************RELOJ MEXICO*******************
        JTextField txtHoraMexico = new JTextField(15);
        add(txtHoraMexico);

        BufferedImage myPicture = null;
        try {
            myPicture = ImageIO.read(new File("mx.png"));
        } catch (IOException ex) {
            Logger.getLogger(Reloj_GUI.class.getName()).log(Level.SEVERE, null, ex);
        }
        JLabel picLabel = new JLabel(new ImageIcon(myPicture));
        add(picLabel);

        Alarma_Thread relojMX = new Alarma_Thread(txtHoraMexico, "MX");

        JButton btnIniciarRelojMX = new JButton("Iniciar");
        add(btnIniciarRelojMX);
        btnIniciarRelojMX.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                relojMX.start();
            }
        });

        JButton btnDetenerRelojMX = new JButton("Detener");
        add(btnDetenerRelojMX);
        btnDetenerRelojMX.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                relojMX.stopThread();
            }
        });

        JButton btnAgregaAlarma = new JButton("Alarma");
        btnAgregaAlarma.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                String strHora = JOptionPane.showInputDialog("¿Hora de la alarma?");
                String strMsg = JOptionPane.showInputDialog("¿Mensaje a mostrar?");
                relojMX.addAlarma(strHora, strMsg);
            }
        });
        add(btnAgregaAlarma);

        //****************RELOJ BRAZIL********************
        JTextField txtHoraBR = new JTextField(15);
        add(txtHoraBR);
        
        BufferedImage myPicture1 = null;
        try {
            myPicture1 = ImageIO.read(new File("br.png"));
        } catch (IOException ex) {
            Logger.getLogger(Reloj_GUI.class.getName()).log(Level.SEVERE, null, ex);
        }
        JLabel picLabe2 = new JLabel(new ImageIcon(myPicture1));
        add(picLabe2);

        Alarma_Thread relojBR = new Alarma_Thread(txtHoraBR, "BR");

        JButton btnIniciarBR = new JButton("Iniciar");
        add(btnIniciarBR);
        btnIniciarBR.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                relojBR.start();
            }
        });

        JButton btnDetenerBR = new JButton("Detener");
        add(btnDetenerBR);
        btnDetenerBR.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                relojBR.stopThread();
            }
        });
        
        JButton btnAgregaAlarmaBR = new JButton("Alarma");
        btnAgregaAlarmaBR.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                String strHora = JOptionPane.showInputDialog("¿Hora de la alarma?");
                String strMsg = JOptionPane.showInputDialog("¿Mensaje a mostrar?");
                relojBR.addAlarma(strHora, strMsg);
            }
        });
        add(btnAgregaAlarmaBR);
        
        
        

        //**************RELOJ UK***********************
        JTextField txtHoraUK = new JTextField(15);
        add(txtHoraUK);
        
        BufferedImage myPicture2 = null;
        try {
            myPicture2 = ImageIO.read(new File("uk.png"));
        } catch (IOException ex) {
            Logger.getLogger(Reloj_GUI.class.getName()).log(Level.SEVERE, null, ex);
        }
        JLabel picLabel2 = new JLabel(new ImageIcon(myPicture2));
        add(picLabel2);

        Alarma_Thread relojUK = new Alarma_Thread(txtHoraUK, "UK");

        JButton btnIniciarUK = new JButton("Iniciar");
        add(btnIniciarUK);
        btnIniciarUK.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                relojUK.start();
            }
        });

        JButton btnDetenerUK = new JButton("Detener");
        add(btnDetenerUK);
        btnDetenerUK.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                relojUK.stopThread();
            }
        });
        
        JButton btnAgregaAlarmaUK = new JButton("Alarma");
        btnAgregaAlarmaUK.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                String strHora = JOptionPane.showInputDialog("¿Hora de la alarma?");
                String strMsg = JOptionPane.showInputDialog("¿Mensaje a mostrar?");
                relojBR.addAlarma(strHora, strMsg);
            }
        });
        add(btnAgregaAlarmaUK);
        

        //***************RELOJ ESPAÑA*****************
        JTextField txtHoraES = new JTextField(15);
        add(txtHoraES);
        
        BufferedImage myPicture3 = null;
        try {
            myPicture3 = ImageIO.read(new File("es.png"));
        } catch (IOException ex) {
            Logger.getLogger(Reloj_GUI.class.getName()).log(Level.SEVERE, null, ex);
        }
        JLabel picLabel3 = new JLabel(new ImageIcon(myPicture3));
        add(picLabel3);
        
        Alarma_Thread relojES = new Alarma_Thread(txtHoraES, "ES");

        JButton btnIniciarES = new JButton("Iniciar");
        add(btnIniciarES);
        btnIniciarES.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                relojES.start();
            }
        });

        JButton btnDetenerES = new JButton("Detener");
        add(btnDetenerES);
        btnDetenerES.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                relojES.stopThread();
            }
        });
        
        JButton btnAgregaAlarmaES = new JButton("Alarma");
        btnAgregaAlarmaES.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                String strHora = JOptionPane.showInputDialog("¿Hora de la alarma?");
                String strMsg = JOptionPane.showInputDialog("¿Mensaje a mostrar?");
                relojBR.addAlarma(strHora, strMsg);
            }
        });
        add(btnAgregaAlarmaES);
        

        setVisible(true);
    }

}
