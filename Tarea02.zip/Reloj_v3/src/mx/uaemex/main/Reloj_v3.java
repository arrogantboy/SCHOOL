
package mx.uaemex.main;

import mx.uaemex.gui.Reloj_GUI;

public class Reloj_v3 {

    public static void main(String[] args) {
        new Reloj_GUI();
        
    }
    
}
